# GodotLoadScreen
32-bit Godot boot splash / load screen scene and assets.

All scenes, scripts, and assets necessary for the bootsplash and scene to work should be included in the file titled "GodotSplash".  All you should have to do is move that folder to your Godot project file and open the "GodotStartupScreen.tscn".  The image to set as the boot splash is "GodotBootSplash.png". 

You should not have to fix any dependencies.  If you do, please let me know, but it is also quite easy to resolve them in the Godot editor.